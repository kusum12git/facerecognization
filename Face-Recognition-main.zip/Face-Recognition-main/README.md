Step1:-First merge all this in one Folder.
Step2- Go thorughout the code for capture key and exiting key.
Step3- Run the first file Face Recognition .py (Make sure the internet is working the code is proper with the same indentation.)
step4- After the image is saved in the Face Recognition , then run the file Face Identification.py for identify. with the same name showing as of the recognized images is saved as .
Thanyou. 
For further refer on the code , it is just the basic implementation with friendly code in python.
